# wx-mina-custom-tabbar
微信小程序自定义tabbar，包含可左右滚动。  

![image](https://github.com/marlti7/wx-mina-custom-tabbar/blob/master/gif/tabbar.gif) 
