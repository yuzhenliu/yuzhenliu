//原型 封装 手风琴
//颜色可以让用户输入 宽度
$.fn.accordion = function(colors,width){
	colors = colors||[];
	width = width||100;
	//定义一个变量来接受 提高效率 this是实例对象
	var $li=this.find("li");
	//定义一个boxlength maxlength avlength
	var boxlength=this.width();
	var maxlength=boxlength-($li.length-1)*width;
	var avlength=boxlength/$li.length;
	// 让对应li中变成colors中对应的颜色 .each()
		$li.each(function(index,element){
		$(element).css("backgroundColor",colors[index]);
	});
		//鼠标经过事件
	 $li.on("mouseenter",function(){
		$(this).stop().animate({width:maxlength}).siblings().stop().animate({width:width});
	});
		//鼠标离开事件
	 $li.on("mouseleave",function(){
		$(".box li").stop().animate({width:avlength});
	});
};